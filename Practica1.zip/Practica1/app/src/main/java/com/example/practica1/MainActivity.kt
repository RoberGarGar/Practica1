package com.example.practica1

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_practica1_activity)

        val editText1: EditText = findViewById(R.id.EDT_text)
        val button1: Button = findViewById(R.id.BT_1)
        val button2: Button = findViewById(R.id.BT_2)
        val button3: Button = findViewById(R.id.BT_3)
        val constraintLayout = findViewById<ConstraintLayout>(R.id.Constraint)

        val bundlecolor=intent.extras
        val dato = bundlecolor?.getString("colorbutton")

        if (dato != null) {
            constraintLayout.setBackgroundColor(Color.parseColor(dato))
        }

        button1.setOnClickListener{

            val editTextInfo: String = editText1.getText().toString()
            val intent = Intent(this, Practica1ActivityB::class.java)
            intent.putExtra("textinfo",editTextInfo)
            startActivity(intent)
        }

       button2.setOnClickListener{

           val intent = Intent(this, Practica1ActivityB::class.java)
           startActivity(intent)

           /*
           No he conseguido realizar este boton
           */

        }

        button3.setOnClickListener{
            val intentWeb = Intent()
            intentWeb.action = Intent.ACTION_VIEW
            intentWeb.data = Uri.parse("https://codelabs.developers.google.com/android-training/")
            startActivity(intentWeb)
        }
    }
}



